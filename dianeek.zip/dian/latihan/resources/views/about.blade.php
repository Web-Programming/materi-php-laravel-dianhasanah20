<div>
    <!-- Simplicity is an acquired taste. - Katharine Gerould -->
</div>
