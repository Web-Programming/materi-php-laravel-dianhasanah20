<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Hasil; Penjumlahan</h1>
    <p>Angka 1: {{$angka1}}</p>
    <p>Angka 2: {{$angka2}}</p>
    <p>Angka 3: {{$angka3}}</p>
    <hr>
    <h2>Total: {{$Total}}<h2>
    
</body>
</html>